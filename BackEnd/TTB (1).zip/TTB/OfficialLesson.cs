﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace TTB.Models
{
	[Table("Get_OfficialLesson")]
	public class OfficialLesson
	{
		[Required]
		public int ID { get; set; }
		[Required]
		public int Teacher_ID { get; set; }
		[Required]
		public int Type_ID { get; set; }
		[Required]
		public int Audience { get; set; }
		[Required]
		public int Day_ID { get; set; }
		[Required]
		public int Time_ID { get; set; }
		[Required]
		public int Group_ID { get; set; }
		[Required]
		public int Title_ID { get;set }
	}
}

