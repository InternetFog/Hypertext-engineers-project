﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.Http;
using Newtonsoft.Json;
using System.Linq;
using System.Threading.Tasks;
using TTB.Models;
namespace TTB.Controllers
{
    [Route("api/[controller]")]
    public class TableController : ControllerBase
    {
        //private readonly IConfiguration _config;
        //public TableController(IConfiguration configuration)
        //{
        //    _config = configuration;
        //}


        //[HttpGet]
        //[Route("testTable")]
        //public IEnumerable<TestTable> Get()
        //{
        //    List<TestTable> result = new List<TestTable>();
        //    SqlConnection sCon = new SqlConnection(_config.GetConnectionString("cs"));
        //    using (var scmd = new SqlCommand("select * from TestTable", sCon))
        //    {
        //        sCon.Open();

        //        using var reader = scmd.ExecuteReader();

        //        while (reader.Read())
        //        {
        //            result.Add(new TestTable()
        //            {
        //                Title = (string)reader[0],
        //                Count = (string)reader[1]
        //            });
        //        }
        //    }
        //    return result;
        //}
        //[HttpGet("{Count}")]
        //public TestTable Get(string Count)
        //{
        //    string sQuery = $"select * from TestTable where Count = {Count}";
        //    SqlConnection sCon = new SqlConnection(_config.GetConnectionString("cs"));
        //    using (var scmd = new SqlCommand(sQuery, sCon))
        //    {
        //        sCon.Open();

        //        using var reader = scmd.ExecuteReader();
        //        reader.Read();
        //        return new TestTable()
        //        {
        //            Title = (string)reader[0],
        //            Count = (string)reader[1]
        //        };
        //    }
        //}



        //[HttpGet]
        //[Route("testTable")]
        //public string testTable(TestTable testTable)
        //{
        //    SqlConnection sCon = new SqlConnection(_config.GetConnectionString("cs").ToString());
        //    SqlCommand scmd = new SqlCommand("INSERT INTO TestTable(Title, Count) VALUES('" + testTable.Title + "', '" + testTable.Count + "'  )", sCon);
        //    sCon.Open();
        //    int i = scmd.ExecuteNonQuery();
        //    sCon.Close();
        //    if (i > 0)
        //    {
        //        return "Inserted succesfully";
        //    }
        //    else
        //    {
        //        return "Insert error";
        //    }
        //    return "";
        //}
    }
}
