﻿using System;

namespace TTB.Interface
{
    public interface ITable
    {
    }
}
