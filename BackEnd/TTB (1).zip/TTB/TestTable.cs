﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
namespace TTB.Models
{
	public class TestTable
	{
		[Required]
		public string Title { get; set; }
		[Required]
		public int Count { get; set; }
	}
}
